Hello,

this is a small project I worked on it my self for over a month its a simple search function through the database using fetch where you have three search parameters Calories, Carbs, Protein.

you need to have your own database with table meal and values name, calories, carbs, protein and source so the js could work.

and have another table where you have to store user data fullname, phone and password and the password is encrypted.
